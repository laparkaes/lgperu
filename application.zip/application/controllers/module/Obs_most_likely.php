<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Obs_most_likely extends CI_Controller {
	
	public function index(){
		redirect('data_upload/obs_most_likely');
	}
	
}
