<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sa_sell_out extends CI_Controller {
	
	public function index(){
		redirect('data_upload/sa_sell_out');
	}

}
