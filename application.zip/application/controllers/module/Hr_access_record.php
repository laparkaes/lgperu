<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hr_access_record extends CI_Controller {

	public function index(){
		redirect('data_upload/hr_access_record');
	}
	
}
