<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gerp_sales_order extends CI_Controller {

	public function index(){
		redirect('data_upload/lgepr_sales_order');
	}
	
}
