<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tax_paperless_document extends CI_Controller {
	
	public function index(){
		redirect('data_upload/tax_paperless_document');
	}

}
