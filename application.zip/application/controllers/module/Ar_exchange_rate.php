<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ar_exchange_rate extends CI_Controller {

	public function index(){
		redirect('data_upload/ar_exchange_rate');
	}

}
