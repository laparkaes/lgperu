<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gerp_stock_update extends CI_Controller {

	public function index(){
		redirect('data_upload/lgepr_stock');
	}
	
}
