<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Obs_gerp extends CI_Controller {

	public function index(){
		redirect('data_upload/obs_gerp');
	}
	
}
